package Model;


public class Camel extends Animal implements Packable {
    public Camel(int id, String name, String birthday) {
        super(id, name, birthday);
    }
}
