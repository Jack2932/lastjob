package Model;



public class Horse extends Animal implements Packable {
    public Horse(String name, String birthday) {
        super(id, name, birthday);
    }
}
