package Model;

public interface Packable {
}
