package Model;


public class Hamster extends Animal implements Petable {
    public Hamster(String name, String birthday) {
        super(id, name, birthday);
    }
}
