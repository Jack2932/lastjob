package Model;


public class Donkey extends Animal implements Packable {
    public Donkey(String name, String birthday) {
        super(id, name, birthday);
    }
}
