package Model;

public interface Petable {
}
