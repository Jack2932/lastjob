package Model;


public class Cat extends Animal implements Petable {
    public Cat(int id, String name, String birthday) {
        super(id, name, birthday);
    }
}
