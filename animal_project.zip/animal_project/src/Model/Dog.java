package Model;


public class Dog extends Animal implements Petable {
    public Dog(String name, String birthday) {
        super(id, name, birthday);
    }
}
